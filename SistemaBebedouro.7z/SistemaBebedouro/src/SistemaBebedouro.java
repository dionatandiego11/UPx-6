import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class SistemaBebedouro {
    private static final Logger logger = Logger.getLogger(SistemaBebedouro.class.getName());

    public static void main(String[] args) {
        // Configuração do logger
        setupLogger();

        // Criação do JFrame (janela)
        JFrame frame = new JFrame("Tela Inicial");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Criação dos componentes da interface
        JLabel matriculaLabel = new JLabel("Matrícula (CPF):");
        matriculaLabel.setBounds(50, 50, 100, 20);
        frame.add(matriculaLabel);

        JTextField matriculaField = new JTextField();
        matriculaField.setBounds(150, 50, 200, 20);
        frame.add(matriculaField);

        JButton submitButton = new JButton("Autenticar");
        submitButton.setBounds(150, 100, 100, 30);
        frame.add(submitButton);

        // Adicionando ação ao botão
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String matricula = matriculaField.getText();
                if (autenticarUsuario(matricula)) {
                    abrirTelaQuantidadeAgua(matricula);
                } else {
                    JOptionPane.showMessageDialog(frame, "Autenticação falhou. Verifique sua matrícula.");
                }
            }
        });

        // Tornar a janela visível
        frame.setVisible(true);
    }

    private static boolean autenticarUsuario(String matricula) {
        // Conectar ao banco de dados e verificar a matrícula
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/seubanco", "usuario", "senha");
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM usuarios WHERE cpf = ?")) {
            statement.setString(1, matricula);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static void abrirTelaQuantidadeAgua(String matricula) {
        JFrame frame = new JFrame("Seleção de Quantidade de Água");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        JLabel quantidadeLabel = new JLabel("Selecione a quantidade de água:");
        quantidadeLabel.setBounds(50, 50, 300, 20);
        frame.add(quantidadeLabel);

        String[] opcoes = {"200ml", "300ml", "500ml", "750ml", "1000ml"};
        JComboBox<String> comboBox = new JComboBox<>(opcoes);
        comboBox.setBounds(50, 100, 150, 30);
        frame.add(comboBox);

        JButton confirmarButton = new JButton("Confirmar");
        confirmarButton.setBounds(220, 100, 100, 30);
        frame.add(confirmarButton);

        confirmarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String quantidadeSelecionada = (String) comboBox.getSelectedItem();
                logAcesso(matricula, quantidadeSelecionada);
                JOptionPane.showMessageDialog(frame, "Quantidade de água selecionada: " + quantidadeSelecionada);
            }
        });

        frame.setVisible(true);
    }

    private static void logAcesso(String matricula, String quantidade) {
        try {
            logger.info("Matrícula: " + matricula + ", Quantidade de Água: " + quantidade);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setupLogger() {
        try {
            FileHandler fh = new FileHandler("acessos.log", true);
            logger.addHandler(fh);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
